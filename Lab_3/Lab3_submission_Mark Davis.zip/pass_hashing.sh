#!/bin/bash

users=( mscott dschrute jhalpert amartin kmalone omartinez abernard plapin shudson mdavis tflenderson cbratton dphilbin mpalmer pbeesly kkapoor )

for i in "${users[@]}"; do openssl passwd -6 $i; done >> out.dat
