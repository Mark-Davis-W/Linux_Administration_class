#!/bin/bash

users=( mscott dschrute jhalpert amartin kmalone omartinez abernard plapin shudson mdavis tflenderson cbratton dphilbin mpalmer pbeesly kkapoor )

for d in /home/* ; do
   sub=`echo "$d" | awk 'BEGIN{FS="/home/"} {print $2}'`
   # echo "$sub"
   for i in "${users[@]}"; do
	   if [[ "$sub" == "$i" ]]; then
	      chown -R $i:$i $d &&
         chmod -R 700 $d &&
         chmod -R g-s $d &&
         echo "$d found!!"
      # else echo "$i not found."
	   fi
  done 
done 
