#!/bin/bash

users=( mscott dschrute jhalpert amartin kmalone omartinez abernard plapin shudson mdavis tflenderson cbratton dphilbin mpalmer pbeesly kkapoor )

for i in "${users[@]}"; do userdel -r $i; done 
